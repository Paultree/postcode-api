package paul.pham.postcode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PostcodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
